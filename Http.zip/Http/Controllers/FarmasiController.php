<?php

namespace App\Http\Controllers;

class FarmasiController extends Controller
{
    public function resep()
    {
        return view('farmasi.resep');
    }
}
